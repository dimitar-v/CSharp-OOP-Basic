﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    public class BankAccount
    {
        private int id;
        private decimal balamce;

        public int Id { get; set; }
        public decimal Balance { get; set; }


    }
}
