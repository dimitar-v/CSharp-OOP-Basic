﻿using System;

namespace Farm
{
    class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
