﻿using Birthday_Celebrations.Core;

namespace Birthday_Celebrations
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
