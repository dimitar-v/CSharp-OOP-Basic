﻿namespace Birthday_Celebrations.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
