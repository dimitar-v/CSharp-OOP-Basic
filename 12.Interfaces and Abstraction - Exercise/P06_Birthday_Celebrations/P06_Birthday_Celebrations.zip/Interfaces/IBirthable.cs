﻿namespace Birthday_Celebrations.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
