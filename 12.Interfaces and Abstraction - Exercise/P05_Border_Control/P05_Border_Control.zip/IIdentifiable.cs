﻿namespace Border_Control
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
