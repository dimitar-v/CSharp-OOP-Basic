﻿using System.Collections.Generic;

namespace MilitaryElite.Interfaces
{
    interface ILieutenantGeneral
    {
        List<string> Soldiers { get; }
    }
}
