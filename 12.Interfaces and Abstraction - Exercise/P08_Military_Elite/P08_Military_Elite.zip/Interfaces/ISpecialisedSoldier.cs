﻿namespace MilitaryElite.Interfaces
{
    interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
