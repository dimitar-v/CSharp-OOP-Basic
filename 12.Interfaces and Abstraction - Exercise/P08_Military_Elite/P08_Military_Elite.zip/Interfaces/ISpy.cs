﻿namespace MilitaryElite.Interfaces
{
    interface ISpy
    {
        int CodeNunber { get; }
    }
}
