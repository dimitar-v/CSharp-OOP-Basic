﻿namespace Food_Shortage.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
