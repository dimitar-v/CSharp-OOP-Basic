﻿namespace Food_Shortage.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }

        void ByeFood();
    }
}
