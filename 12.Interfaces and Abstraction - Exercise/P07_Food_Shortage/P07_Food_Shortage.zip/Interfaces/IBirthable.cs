﻿namespace Food_Shortage.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
