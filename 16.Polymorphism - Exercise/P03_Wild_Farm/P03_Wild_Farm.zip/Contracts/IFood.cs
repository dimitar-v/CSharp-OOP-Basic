﻿namespace WildFarm.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
