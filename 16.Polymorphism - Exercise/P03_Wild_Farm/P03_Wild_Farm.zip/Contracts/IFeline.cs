﻿namespace WildFarm.Contracts
{
    public interface IFeline
    {
        string Breed { get; }
    }
}
