﻿namespace WildFarm.Contracts
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
