﻿namespace WildFarm.Contracts
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}
