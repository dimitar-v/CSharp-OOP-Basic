﻿using Farm.Core;

namespace Farm
{
    class StarUp // 83 / 100
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
