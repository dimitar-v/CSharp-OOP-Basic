﻿using System;
using System.Collections.Generic;

namespace P06_Animals
{
    class StarUp
    {
        static void Main(string[] args)
        {
            var animals = new List<Animals>();
            string command;

            while ((command = Console.ReadLine()?.ToLower()) != "beast!")
            {
                var info = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                try
                {
                    switch (command)
                    {
                        case "dog":
                            if (info.Length < 3) InvalidInput();
                            animals.Add(new Dog(info[0], int.Parse(info[1]), info[2]));
                            break;
                        case "cat":
                            if (info.Length < 3) InvalidInput();
                            animals.Add(new Cat(info[0], int.Parse(info[1]), info[2]));
                            break;
                        case "frog":
                            if (info.Length < 3) InvalidInput();
                            animals.Add(new Frog(info[0], int.Parse(info[1]), info[2]));
                            break;
                        case "kittens":
                            if (info.Length < 2) InvalidInput();
                            animals.Add(new Kittens(info[0], int.Parse(info[1])));
                            break;
                        case "tomcat":
                            if (info.Length < 2) InvalidInput();
                            animals.Add(new Tomcat(info[0], int.Parse(info[1])));
                            break;
                        default:
                            InvalidInput();
                            break;
                    }
                }
                catch (ArgumentException ae)
                {
                    Console.WriteLine(ae.Message);
                }
            }

            animals.ForEach(a => Console.WriteLine(a));

        }

        private static void InvalidInput()
        {
            throw new ArgumentException("Invalid input!");
        }
    }
}
