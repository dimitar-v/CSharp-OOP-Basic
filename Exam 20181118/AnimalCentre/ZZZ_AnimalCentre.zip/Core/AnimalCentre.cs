﻿using AnimalCentre.Facturies;
using AnimalCentre.Models.Contracts;
using AnimalCentre.Models.Entities;
using AnimalCentre.Models.Entities.Procedures;
using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Core
{
    class AnimalCentre
    {
        private AnimalsFactory animalFactory;
        private ProcedurFactory procedurFactory;

        public Dictionary<string, List<string>> adopted;
        private Dictionary<string, Procedure> procedures;

        private Hotel hotel;

        public AnimalCentre()
        {
            animalFactory = new AnimalsFactory();
            procedurFactory = new ProcedurFactory();
            adopted = new Dictionary<string, List<string>>();
            procedures = new Dictionary<string, Procedure>();
            hotel = new Hotel();
        }

        public string RegisterAnimal(string type, string name, int energy, int happiness, int procedureTime)
        {
            IAnimal animal = animalFactory.CreateAnimal(type, name, happiness, energy, procedureTime);

            hotel.Accommodate(animal);

            return $"Animal {name} registered successfully";
        }

        public string Chip(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("Chip"))
            {
                procedures["Chip"] = procedurFactory.CreateProcedure("Chip");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["Chip"].DoService(animal, procedureTime);

            return $"{name} had chip procedure";
        }

        public string Vaccinate(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("Vaccinate"))
            {
                procedures["Vaccinate"] = procedurFactory.CreateProcedure("Vaccinate");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["Vaccinate"].DoService(animal, procedureTime);

            return $"{name} had vaccination procedure";
        }

        public string Fitness(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("Fitness"))
            {
                procedures["Fitness"] = procedurFactory.CreateProcedure("Fitness");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["Fitness"].DoService(animal, procedureTime);

            return $"{name} had fitness procedure";
        }

        public string Play(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("Play"))
            {
                procedures["Play"] = procedurFactory.CreateProcedure("Play");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["Play"].DoService(animal, procedureTime);

            return $"{name} was playing for {procedureTime} hours";
        }

        public string DentalCare(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("DentalCare"))
            {
                procedures["DentalCare"] = procedurFactory.CreateProcedure("DentalCare");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["DentalCare"].DoService(animal, procedureTime);

            return $"{name} had dental care procedure";
        }

        public string NailTrim(string name, int procedureTime)
        {
            if (!procedures.ContainsKey("NailTrim"))
            {
                procedures["NailTrim"] = procedurFactory.CreateProcedure("NailTrim");
            }
            IAnimal animal = hotel.GetAnimal(name);
            procedures["NailTrim"].DoService(animal, procedureTime);

            return $"{name} had nail trim procedure";
        }

        public string Adopt(string animalName, string owner)
        {
            IAnimal animal = hotel.GetAnimal(animalName);
            hotel.Adopt(animalName, owner);

            if (!adopted.ContainsKey(owner))
            {
                adopted[owner] = new List<string>();
            }

            adopted[owner].Add(animal.Name);

            string result;

            if (animal.IsChipped)
            {
                result = $"{owner} adopted animal with chip";
            }
            else
            {
                result = $"{owner} adopted animal without chip";
            }

            return result;
        }

        public string History(string type)
        {
            return procedures[type].History();
        }

    }
}
