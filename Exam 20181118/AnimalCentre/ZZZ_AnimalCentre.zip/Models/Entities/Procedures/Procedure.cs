﻿using AnimalCentre.Models.Contracts;
using System.Collections.Generic;
using System.Text;

namespace AnimalCentre.Models.Entities.Procedures
{
    public abstract class Procedure : IProcedure
    {
        private List<IAnimal> procedureHistory;

        public Procedure()
        {
            procedureHistory = new List<IAnimal>();
        }

        protected IReadOnlyCollection<IAnimal> ProcedureHistory => procedureHistory.AsReadOnly();
        //collection of Animals accessible only by the child classes (will hold information about each procedure and its animals)

        public virtual void DoService(IAnimal animal, int procedureTime) { }

        public string History()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.GetType().Name);

            foreach (var animal in procedureHistory)
            {
                sb.AppendLine($"    Animal type: {animal.GetType().Name} - {animal.Name} - Happiness: {animal.Happiness} - Energy: {animal.Energy}");
            }

            return sb.ToString().Trim();
        }

        protected void AddProcedure(string procedure, IAnimal animal)
        {
            procedureHistory.Add(animal);
        }
    }
}
