﻿namespace StorageMaster.Entities.Vehicles
{
    public class Van : Vehicle
    {
        private const int Capacity = 2;

        public Van()
            : base(Capacity) { }
    }
}
