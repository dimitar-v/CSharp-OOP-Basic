﻿namespace P03_JediGalaxy
{
    public class Player
    {
        public int Row { get; set; }
        public int Col { get; set; }

        public Player(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
}
