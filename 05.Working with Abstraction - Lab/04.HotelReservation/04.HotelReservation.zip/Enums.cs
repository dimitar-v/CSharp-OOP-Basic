﻿namespace HotelReservation
{
    public enum Season
    {
        Autumn = 1,
        Spring,
        Winter,
        Summer
    }

    public enum Discount
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
